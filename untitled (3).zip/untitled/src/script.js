
function mostrar(seccion) {
  document.querySelectorAll(".pagina").forEach(p => {
    p.classList.remove("activa");
  });

  document.getElementById(seccion).classList.add("activa");
}

let listaFavoritos = [];

function favorito(estilo) {
  if (!listaFavoritos.includes(estilo)) {
    listaFavoritos.push(estilo);
  }

  document.getElementById("favoritos").textContent =
    "Mis favoritos: " + listaFavoritos.join(", ");
}

function recomendar() {
  let estilo = document.getElementById("respuesta").value;

  document.getElementById("recomendacion").textContent =
    "¡Te recomendamos el estilo " + estilo + "! Explora sus características.";
}

function calcular() {
  let muebles = Number(document.getElementById("muebles").value) || 0;
  let iluminacion = Number(document.getElementById("iluminacion").value) || 0;
  let decoracion = Number(document.getElementById("decoracion").value) || 0;
  let pintura = Number(document.getElementById("pintura").value) || 0;

  if ([muebles, iluminacion, decoracion, pintura].some(n => n < 0)) {
    document.getElementById("total").textContent =
      "Ingresa cantidades positivas.";
    return;
  }

  let total = muebles + iluminacion + decoracion + pintura;

  document.getElementById("total").textContent =
    "Total: Bs " + total.toLocaleString("es-BO");
}

document.getElementById("formulario").addEventListener("submit", function(event) {
  event.preventDefault();

  let nombre = document.getElementById("nombre").value;

  document.getElementById("confirmacion").textContent =
    "¡Gracias, " + nombre + "! Tu mensaje fue registrado.";

  this.reset();
});
